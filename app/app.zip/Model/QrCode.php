<?php

class QrCode extends AppModel {

    public $useTable = 'scan_qr';
    public $primaryKey = 'id_scan_QR';
    public $belongsTo = array('Mission', 'User');
    
    public function mesPoints($idUser){
         return $this->query("SELECT scan.*, mission.point_offre, mission.code_QR1, mission.code_QR2, magasin.nom_mag, magasin.id_magasin FROM scan_qr scan JOIN mission ON scan._id_mission=mission.id_mission JOIN magasin ON magasin.id_magasin=mission._id_magasin WHERE scan.id_user = $idUser");
    }
     

}
