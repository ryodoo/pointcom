<?php

class Magasin extends AppModel {

    public $useTable = 'magasin';
    public $primaryKey = 'id_magasin';
    public $hasMany = array(
    'MagasinHasMission' => array(
    'className' => 'MagasinHasMission',
    'foreignKey' => '_id_magasin',
    'dependent'=> true,
    )
    );

    public $validate = array(
        'nom_mag' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Nom du magasin est requis'
            )
        ),
        'nom_mag' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Nom du magasin est requis'
            )
        )
    );

    public function liste(){
        return $this->query("SELECT magasin.*, (select count(*) from mission where mission._id_magasin = magasin.id_magasin) as nb_offres, (select count(*) from scan_qr where _id_mission in (select id_mission from mission where mission._id_magasin = magasin.id_magasin)) as nb_clients FROM magasin");
    }

    public function miens($idUser){
         return $this->query("SELECT magasin.*, (select count(*) from mission where mission.`_id_magasin` = magasin.id_magasin) as nb_offres, (select count(*) from scan_qr where _id_mission in (select id_mission from mission where mission._id_magasin = magasin.id_magasin)) as nb_clients FROM magasin where user_id = $idUser");
    }

    public function magasinById($id){
         return $this->query("SELECT * FROM Magasin WHERE id_magasin = $id");
    }

    public function maxid(){
        return $this->query("SELECT max(id_magasin) as max FROM magasin");
    }
}
