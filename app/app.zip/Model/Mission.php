<?php

class Mission extends AppModel {

    public $useTable = 'mission';
    public $primaryKey = 'id_mission';
    public $hasMany = array(
            'MagasinHasMission' => array(
                            'className' => 'MagasinHasMission',
                            'foreignKey' => '_id_mission',
                            'dependent'=> true
            ),  'QrCode' => array(
                            'className' => 'QrCode',
                            'foreignKey' => '_id_mission',
                            'dependent'=> true
            )
    );


    public function liste() {
        return $this->query("SELECT Mission. * , Magasin.id_magasin, Magasin.nom_mag, (SELECT COUNT( * ) FROM scan_qr WHERE _id_mission = Mission.id_mission ) AS nbUser FROM Mission JOIN Magasin ON Magasin.id_magasin = mission._id_magasin");
    }

    public function mesMissions($idUser) {
        return $this->query("SELECT Mission.*, (SELECT count(*) FROM scan_qr WHERE _id_mission = Mission.id_mission) as nbUser, Magasin.nom_mag  FROM Mission JOIN Magasin ON Magasin.id_magasin=mission._id_magasin  where Magasin.user_id = $idUser order by date_offre desc");
    }

    public function mesMissionsEnCours($idUser) {
        return $this->query("SELECT Mission.*, (SELECT count(*) FROM scan_qr WHERE _id_mission = Mission.id_mission) as nbUser, Magasin.nom_mag  FROM Mission JOIN Magasin ON Magasin.id_magasin=mission._id_magasin  where Magasin.user_id = $idUser  order by date_offre desc");
    }

    public function magasins($user) {
        return $this->query("SELECT magasin.*, (select count(*) from mission where _id_magasin = magasin.id_magasin) as nb_offres, (select count(*) from scan_qr where _id_mission in (select id_mission from mission where mission._id_magasin = magasin.id_magasin)) as nb_clients FROM magasin where user_id = $user");
    }

    public function graphe($date1, $date2, $idUser) {
        return $this->query("SELECT count(*) as nb FROM `scan_qr` WHERE `date_scan1` < '$date1' and `date_scan1` > '$date2' and `_id_mission` in (select id_mission from mission where _id_magasin in (select id_magasin from magasin where user_id = $idUser))");
    }

    public function grapheMission($date1, $date2, $idMission) {
        return $this->query("SELECT count(*) as nb FROM `scan_qr` WHERE `date_scan1` < '$date1' and `date_scan1` > '$date2' and `_id_mission` = $idMission ");
    }

    public function detailsParMission($idMission) {
        return $this->query("SELECT scan_qr.*, user.nom_complet ,user.sexe FROM `scan_qr` JOIN user ON user.id = scan_qr.id_user WHERE `_id_mission` = $idMission order by 	date_scan1 desc");
    }

    public function newMissions() {
        $today = date("Y-m-d H:i:s", time());
        $avant1=strtotime($today)-86400;
        $avant=date("Y-m-d H:i:s",$avant1);
        return $this->query("SELECT * FROM mission WHERE date_offre >= '$avant' ");
    }

}
