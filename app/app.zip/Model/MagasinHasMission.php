<?php

class MagasinHasMission extends AppModel{
	
	public $useTable = 'magasin_has_mission';
        public $primaryKey = '_id';
        public $belongsTo = array('mission', 'magasin');
	
}