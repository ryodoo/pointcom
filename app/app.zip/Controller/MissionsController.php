<?php
class MissionsController extends AppController {

    public function isAuthorized($user) {
        if($user['role_user'] == "mobile") {
            return false;
        }
        if($user['role_user'] == "admin") {
            if ($this->action === 'liste' || $this->action === 'graphe'|| $this->action === 'index' || $this->action === 'view' || $this->action === 'delete' || $this->action === 'code') {
                return true;
            }else return false;
        }else {
            if ($user['role_user'] == "vendeur" && ($this->action === 'add' || $this->action === 'view' ||$this->action === 'graphe' || $this->action === 'mine' || $this->action === 'delete' || $this->action === 'edit' || $this->action === 'code') || ($this->action === 'getmission')|| ($this->action === 'delimage') ) {
                return true;
            }else return false;
        }
        return parent::isAuthorized($user);
    }

    public function mine() {
        $missions = $this->Mission->mesMissions($this->Session->read('Auth.User.id'));
        $this->set(compact('missions'));
    }

    public function view($id) {
        $mission = $this->Mission->findByIdMission($id);
        $this->set('mission', $mission);
    }

    public function add() {
        $userId = $this->Session->read('Auth.User.id');
        $this->loadModel('Magasin');
        $magasins = $this->Magasin->find(
                'list', array(
                'conditions' => array("user_id = " => $userId) ,
                'recursive' => -1,
                'fields' => 'Magasin.nom_mag'));
        $this->set(compact('magasins'));

        if ($this->request->is('post')) {
            if(isset($this->request->data['Magasin']['name'])) {
                $magasinName = $this->request->data['Magasin']['name'];
                $this->set(compact('magasinName'));
            }
            if(isset($this->request->data['Mission'])) {
                $this->request->data['Mission']['_id_magasin']=$this->request->data['Mission']['magasin'];
                if($this->request->data['Mission']['point_offre'] > $this->Session->read('Auth.User.point')) {
                    $this->Session->setFlash(__('Nombre de points insuffisant'));
                    return ;
                }
                $this->Mission->create();
                $file=@$this->request->data['Mission']['image']['tmp_name'];
                if(!empty($file)) {
                    $date=date('H-i-s');
                    $this->request->data['Mission']['image']=$date.''.$this->request->data['Mission']['image']['name'];
                    move_uploaded_file($file,'img/mission/'.$this->request->data['Mission']['image']);
                    $this->fctredimimage(75, 75, '../webroot/img/missionmobile/', '', '../webroot/img/mission/', $this->request->data['Mission']['image']);
                               
                }
                else
                    $this->request->data['Mission']['image']="";
                $this->request->data['Mission']['date_offre'] = date('Y-m-d', strtotime($this->request->data['Mission']['dateOffre']));
                $this->request->data['Mission']['date_expiration'] =  date('Y-m-d', strtotime($this->request->data['Mission']['dateExpiration']));
                $this->request->data['Mission']['code_QR1'] =  md5($this->request->data['Mission']['magasin']."||".$this->request->data['Mission']['temps']."||".$this->request->data['Mission']['points_par_user']);
                if($this->request->data['Mission']['type_offre'] == "visiter")
                    $this->request->data['Mission']['code_QR2'] = md5($this->request->data['Mission']['magasin']."||".$this->request->data['Mission']['point_offre']);
                $points_offre = $this->request->data['Mission']['point_offre'];

                if($this->request->data['Mission']['type_offre'] == "visiter") {
                    $this->request->data['Mission']['point_offre'] = $this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user'];
                }
                $this->Mission->save($this->request->data);
                $this->Mission->MagasinHasMission->save(array("_id_magasin" => $this->request->data['Mission']['magasin'], "_id_mission" => $this->Mission->id));
                if($this->request->data['Mission']['type_offre'] == "visiter") {
                    $this->request->data['Mission']['point_offre'] = $points_offre;
                    $points = $this->Session->read('Auth.User.point') - ($this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user']);
                }else
                    $points = $this->Session->read('Auth.User.point') - $this->request->data['Mission']['point_offre'];
                $this->Session->write('Auth.User.point', $points);
                $this->loadModel('User');
                $this->User->save(array("id" => $this->Session->read('Auth.User.id'), "point" => $points));
                $this->Session->setFlash(__('Mission bien créée'));
                return $this->redirect(array('action' => 'mine'));
            }
        }
    }


    public function edit($idMission) {
        $mission = $this->Mission->find("first", array("conditions" => array("id_mission" => $idMission), "recursive" => -1));
        $this->set('mission', $mission);

        if((strtotime($mission['Mission']['date_offre'])+600) < time())
            return $this->redirect(array('controller' => 'missions', 'action' => 'mine'));


        if ($this->request->is('post')) {
            $file=@$this->request->data['Mission']['image']['tmp_name'];
            if(!empty($file)) {
                $date=date('H-i-s');
                $this->request->data['Mission']['image']=$date.''.$this->request->data['Mission']['image']['name'];
                move_uploaded_file($file,'img/mission/'.$this->request->data['Mission']['image']);
                $this->fctredimimage(75, 75, '../webroot/img/missionmobile', '', '../webroot/img/mission/', $this->request->data['Mission']['image']);
            }
            else
                $this->request->data['Mission']['image']="";
            $idMagasin=$this->Mission->findByIdMission($idMission);
            $idMagasin=$idMagasin['Mission']['_id_magasin'];
            if($this->request->data['Mission']['point_offre'] > $mission['Mission']['point_offre']) {
                if(($this->request->data['Mission']['point_offre'] - $mission['Mission']['point_offre']) > $this->Session->read('Auth.User.point')) {
                    $this->Session->setFlash(__('Nombre de points insuffisant'));
                    return ;
                }
            }
            if(!isset ($this->request->data['Mission']['dateExpiration']) || $this->request->data['Mission']['dateExpiration'] == null) {
                $this->Session->setFlash(__('Date d\'expiration obligatoire '));
                return ;
            }
            $this->request->data['Mission']['date_expiration'] =  date('Y-m-d', strtotime($this->request->data['Mission']['dateExpiration']));
            if($this->request->data['Mission']['type_offre'] == "visiter")
                $this->request->data['Mission']['code_QR2'] = $idMagasin."||".$this->request->data['Mission']['point_offre'];
            else {
                $this->request->data['Mission']['code_QR2'] = "";
                $this->request->data['Mission']['max_use'] = null;
                $this->request->data['Mission']['points_par_user'] = null;
                $this->request->data['Mission']['temps'] = null;
            }
            $this->request->data['Mission']['code_QR1'] = $idMagasin."||".$this->request->data['Mission']['temps']."||".$this->request->data['Mission']['points_par_user'];
            $points_offre = $this->request->data['Mission']['point_offre'];
            if($this->request->data['Mission']['type_offre'] == "visiter") {
                $this->request->data['Mission']['point_offre'] = $this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user'];
            }
            if ($this->Mission->save($this->request->data)) {
                if($this->request->data['Mission']['type_offre'] == "visiter") {
                    $this->request->data['Mission']['point_offre'] = $points_offre;
                    if(($this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user']) > $mission['Mission']['point_offre'])
                        $points = $this->Session->read('Auth.User.point') - (($this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user']) - $mission['Mission']['point_offre']);
                    else
                        $points = $this->Session->read('Auth.User.point') + ($mission['Mission']['point_offre'] - ($this->request->data['Mission']['max_use']*$this->request->data['Mission']['points_par_user']));
                }
                else {
                    if($this->request->data['Mission']['point_offre'] > $mission['Mission']['point_offre'])
                        $points = $this->Session->read('Auth.User.point') - ($this->request->data['Mission']['point_offre'] - $mission['Mission']['point_offre']);
                    else
                        $points = $this->Session->read('Auth.User.point') + ($mission['Mission']['point_offre'] - $this->request->data['Mission']['point_offre']);
                }

                $this->Session->write('Auth.User.point', $points);
                $this->loadModel('User');
                $this->User->save(array("user_id" => $this->Session->read('Auth.User.user_id'), "point" => $points));
                $this->Session->setFlash(__('Mission a été modifiée'));
                return $this->redirect(array('controller' => 'missions', 'action' => 'mine'));
            }else {
                $this->Session->setFlash(__('Mission n\'a pas été modifiée'));
            }

        }
    }

    public function liste() {
        $missions = $this->Mission->liste();
        $this->set(compact('missions'));
    }

    public function index() {
        if($this->Session->check('Auth.User.user_id')) {
            $userId = $this->Session->read('Auth.User.user_id');
            $missions = $this->Mission->myMissions($userId);
            $this->set(compact('missions'));
        }
    }

    public function graphe($idMission) {
        $avant = date("Y-m-d H:i:s", time());
        for($t = 0; $t<10; $t++) {
            $now = $avant;
            $avant1=strtotime($avant)-3600;
            $avant=date("Y-m-d H:i:s",$avant1);
            $missions = $this->Mission->grapheMission($now, $avant, $idMission);
            $T[$now] = $missions[0][0]["nb"];
        }
        if(!empty($T)) {
            $liste =  array_reverse($T);
            $this->set(compact('liste'));
        }

        $qrs = $this->Mission->detailsParMission($idMission);
        $this->set(compact('qrs')); //debug($qrs);
    }

    public function delete($id) {
        if($this->Mission->delete($id, true))
            $this->Session->setFlash(__('Mission a été supprimée'));
        else
            $this->Session->setFlash(__('Mission n\'a pas été supprimée'));
        if($this->Session->read('Auth.User.role_user') == "vendeur")
            return $this->redirect(array('controller' => 'missions', 'action' => 'mine'));
        else return $this->redirect(array('controller' => 'missions', 'action' => 'liste'));
    }

    public function code($code,$chaine) {
        $this->set(compact('chaine','code'));
    }

    function getmission($id=null) {
        $this->Mission->recursive = 1;
        $mission=$this->Mission->findByIdMission($id);
        return $mission;
    }

    function delimage($id=null,$name=null) {
        $this->Mission->id=$id;
        $this->Mission->saveField('image', null);
        unlink("img/mission/".$name);
        $this->Session->setFlash(__('image Supprimer'));
        $this->redirect(array('action' => 'edit',$id));
    }



    // © Jérome Réaux : http://j-reaux.developpez.com - http://www.jerome-reaux-creations.fr
// ---------------------------------------------------
// Fonction de REDIMENSIONNEMENT physique "PROPORTIONNEL" et Enregistrement
// ---------------------------------------------------
// retourne : true si le redimensionnement et l'enregistrement ont bien eu lieu, sinon false
// ---------------------
// La FONCTION : fctredimimage ($W_max, $H_max, $rep_Dst, $img_Dst, $rep_Src, $img_Src)
// Les paramètres :
// - $W_max : LARGEUR maxi finale --> ou 0
// - $H_max : HAUTEUR maxi finale --> ou 0
// - $rep_Dst : repertoire de l'image de Destination (déprotégé) --> ou '' (même répertoire)
// - $img_Dst : NOM de l'image de Destination --> ou '' (même nom que l'image Source)
// - $rep_Src : repertoire de l'image Source (déprotégé)
// - $img_Src : NOM de l'image Source
// ---------------------
// 3 options :
// A- si $W_max!=0 et $H_max!=0 : a LARGEUR maxi ET HAUTEUR maxi fixes
// B- si $H_max!=0 et $W_max==0 : image finale a HAUTEUR maxi fixe (largeur auto)
// C- si $W_max==0 et $H_max!=0 : image finale a LARGEUR maxi fixe (hauteur auto)
// Si l'image Source est plus petite que les dimensions indiquées : PAS de redimensionnement.
// ---------------------
// $rep_Dst : il faut s'assurer que les droits en écriture ont été donnés au dossier (chmod)
// - si $rep_Dst = ''   : $rep_Dst = $rep_Src (même répertoire que l'image Source)
// - si $img_Dst = '' : $img_Dst = $img_Src (même nom que l'image Source)
// - si $rep_Dst='' ET $img_Dst='' : on ecrase (remplace) l'image source !
// ---------------------
// NB : $img_Dst et $img_Src doivent avoir la meme extension (meme type mime) !
// Extensions acceptées (traitees ici) : .jpg , .jpeg , .png
// Pour Ajouter d autres extensions : voir la bibliotheque GD ou ImageMagick
// (GD) NE fonctionne PAS avec les GIF ANIMES ou a fond transparent !
// ---------------------
// UTILISATION (exemple) :
// $redimOK = fctredimimage(120,80,'reppicto/','monpicto.jpg','repimage/','monimage.jpg');
// if ($redimOK==true) { echo 'Redimensionnement OK !';  }
// ---------------------------------------------------
    function fctredimimage($W_max, $H_max, $rep_Dst, $img_Dst, $rep_Src, $img_Src) {
        $condition = 0;
        // Si certains paramètres ont pour valeur '' :
        if ($rep_Dst=='') {
            $rep_Dst = $rep_Src;
        } // (même répertoire)
        if ($img_Dst=='') {
            $img_Dst = $img_Src;
        } // (même nom)
        // ---------------------
        // si le fichier existe dans le répertoire, on continue...
        if (file_exists($rep_Src.$img_Src) && ($W_max!=0 || $H_max!=0)) {
            // ----------------------
            // extensions acceptées :
            $extension_Allowed = 'jpg,jpeg,png';	// (sans espaces)
            // extension fichier Source
            $extension_Src = strtolower(pathinfo($img_Src,PATHINFO_EXTENSION));
            // ----------------------
            // extension OK ? on continue ...
            if(in_array($extension_Src, explode(',', $extension_Allowed))) {
                // ------------------------
                // récupération des dimensions de l'image Src
                $img_size = getimagesize($rep_Src.$img_Src);
                $W_Src = $img_size[0]; // largeur
                $H_Src = $img_size[1]; // hauteur
                // ------------------------
                // condition de redimensionnement et dimensions de l'image finale
                // ------------------------
                // A- LARGEUR ET HAUTEUR maxi fixes
                if ($W_max!=0 && $H_max!=0) {
                    $ratiox = $W_Src / $W_max; // ratio en largeur
                    $ratioy = $H_Src / $H_max; // ratio en hauteur
                    $ratio = max($ratiox,$ratioy); // le plus grand
                    $W = $W_Src/$ratio;
                    $H = $H_Src/$ratio;
                    $condition = ($W_Src>$W) || ($W_Src>$H); // 1 si vrai (true)
                }
                // ------------------------
                // B- HAUTEUR maxi fixe
                if ($W_max==0 && $H_max!=0) {
                    $H = $H_max;
                    $W = $H * ($W_Src / $H_Src);
                    $condition = ($H_Src > $H_max); // 1 si vrai (true)
                }
                // ------------------------
                // C- LARGEUR maxi fixe
                if ($W_max!=0 && $H_max==0) {
                    $W = $W_max;
                    $H = $W * ($H_Src / $W_Src);
                    $condition = ($W_Src > $W_max); // 1 si vrai (true)
                }
                // ---------------------------------------------
                // REDIMENSIONNEMENT si la condition est vraie
                // ---------------------------------------------
                // - Si l'image Source est plus petite que les dimensions indiquées :
                // Par defaut : PAS de redimensionnement.
                // - Mais on peut "forcer" le redimensionnement en ajoutant ici :
                // $condition = 1; (risque de perte de qualité)
                if ($condition==1) {
                    // ---------------------
                    // creation de la ressource-image "Src" en fonction de l extension
                    switch($extension_Src) {
                        case 'jpg':
                        case 'jpeg':
                            $Ress_Src = imagecreatefromjpeg($rep_Src.$img_Src);
                            break;
                        case 'png':
                            $Ress_Src = imagecreatefrompng($rep_Src.$img_Src);
                            break;
                    }
                    // ---------------------
                    // creation d une ressource-image "Dst" aux dimensions finales
                    // fond noir (par defaut)
                    switch($extension_Src) {
                        case 'jpg':
                        case 'jpeg':
                            $Ress_Dst = imagecreatetruecolor($W,$H);
                            break;
                        case 'png':
                            $Ress_Dst = imagecreatetruecolor($W,$H);
                            // fond transparent (pour les png avec transparence)
                            imagesavealpha($Ress_Dst, true);
                            $trans_color = imagecolorallocatealpha($Ress_Dst, 0, 0, 0, 127);
                            imagefill($Ress_Dst, 0, 0, $trans_color);
                            break;
                    }
                    // ---------------------
                    // REDIMENSIONNEMENT (copie, redimensionne, re-echantillonne)
                    imagecopyresampled($Ress_Dst, $Ress_Src, 0, 0, 0, 0, $W, $H, $W_Src, $H_Src);
                    // ---------------------
                    // ENREGISTREMENT dans le repertoire (avec la fonction appropriee)
                    switch ($extension_Src) {
                        case 'jpg':
                        case 'jpeg':
                            imagejpeg ($Ress_Dst, $rep_Dst.$img_Dst);
                            break;
                        case 'png':
                            imagepng ($Ress_Dst, $rep_Dst.$img_Dst);
                            break;
                    }
                    // ------------------------
                    // liberation des ressources-image
                    imagedestroy ($Ress_Src);
                    imagedestroy ($Ress_Dst);
                }
                // ------------------------
            }
        }
        // ---------------------------------------------------
        // retourne : true si le redimensionnement et l'enregistrement ont bien eu lieu, sinon false
        if ($condition==1 && file_exists($rep_Dst.$img_Dst)) {
            return true;
        }
        else {
            return false;
        }
        // ---------------------------------------------------
    }

}
