<?php
App::uses('AppController', 'Controller');

class RechargesController extends AppController {

   public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('cadeau','view');
   }

   public function isAuthorized($user)
   {
        if($user['role_user'] == "mobile" )
        {
            if ($this->action === 'view' || $this->action === 'miens')
                return true;
            else
                return false;
        }
        else
        {
            if($user['role_user'] == "admin")                
                    return true;
        }
        return false;
    }
    public function index() {
        $this->Recharge->recursive = 0;
        $this->set('recharges', $this->paginate());
    }

    public function miens() {
        $this->Recharge->recursive = -1;
        $recharges=$this->Recharge->find('all',array('conditions'=>array('Recharge.user_id'=>$this->Auth->user('id'))));
        $this->set('recharges', $recharges);
    }

    function view($id)
    {
        $this->Recharge->recursive = -1;
        $recharge=$this->Recharge->findById($id);
        $this->set('recharge', $recharge);
    }




    public function add() {
        if ($this->request->is('post'))
        {
            $this->Recharge->create();
            $this->request->data['Recharge']['hachage']=rand(1, 40);
            $this->request->data['Recharge']['hachage+']=$this->request->data['Recharge']['hachage']*$this->request->data['Recharge']['hachage+']-$this->request->data['Recharge']['hachage'];
            $this->request->data['Recharge']['recharge']=9*$this->request->data['Recharge']['hachage']*$this->request->data['Recharge']['hachage+'];
            
            if ($this->Recharge->save($this->request->data)) {
                $this->Session->setFlash(__(' Recharge Ajouter'));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__(' Recharge ne veux pas s\'ajouter a la base?'));
            }
        }
    }

    public function edit($id = null)
    {
        $this->Recharge->id = $id;
        if (!$this->Recharge->exists()) {
            throw new NotFoundException(__('Invalide recharge'));
        }
        if ($this->request->is('post') || $this->request->is('put'))
        {
            $this->request->data['Recharge']['hachage']=rand(1, 40);
            $this->request->data['Recharge']['hachage+']=$this->request->data['Recharge']['hachage']*$this->request->data['Recharge']['hachage+']-$this->request->data['Recharge']['hachage'];
            $this->request->data['Recharge']['recharge']=9*$this->request->data['Recharge']['hachage']*$this->request->data['Recharge']['hachage+'];
            
            if ($this->Recharge->save($this->request->data)) {
                $this->Session->setFlash(__('The recharge Modifier'));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('Erreur a chef.'));
            }
        } else {
            $this->request->data = $this->Recharge->read(null, $id);
        }
    }

    /**
     * delete method
     *
     * @param string $id
     * @return void
     */
    public function delete($id = null) {
        if (!$this->request->is('post')) {
            throw new MethodNotAllowedException();
        }
        $this->Recharge->id = $id;
        if (!$this->Recharge->exists()) {
            throw new NotFoundException(__('Invalid recharge'));
        }
        if ($this->Recharge->delete()) {
            $this->Session->setFlash(__('Recharge deleted'));
            $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('Recharge was not deleted'));
        $this->redirect(array('action' => 'index'));
    }

    function cadeau($type=null)
    {
         $this->Recharge->recursive = -1;
         $cadeau=$this->Recharge->find('all', array('group' => 'point,operateur'));
         if($type!=null)
         {
             $array_info[] = array('id'=>$cadeau['Recharge']['id'],'point' => $cadeau['Recharge']['point']
                 , 'prix'=>$cadeau['Recharge']['prix'],'operateur'=>$cadeau['Recharge']['operateur'],
                 'image'=>"http://myblan.com/img/cadeaux/".$cadeau['Recharge']['operateur'].'_'.$cadeau['Recharge']['prix'].'jpg'
             );
           $json=json_encode($array_info);
           exit();
         }
         $this->set('cads', $cadeau);

    }
}
