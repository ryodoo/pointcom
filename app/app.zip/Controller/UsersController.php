<?php
class UsersController extends AppController {

    public function isAuthorized($user) {
        if($user['role_user'] != "admin") {
            if ($this->action === 'view' || $this->action === 'admin' || $this->action === 'paiement' || $this->action === 'liste' || $this->action === 'modifier') {
                return false;
            }
        }
        return parent::isAuthorized($user);
    }

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('addfrommobile','add', 'logout', 'forgotten', 'valider', 'reinitialiser', 'accueil', 'apropos', 'vendeur', 'membre', 'contact');
    }

    public function index() {
        $this->loadModel('Mission');
        $missions = $this->Mission->mesMissionsEnCours($this->Session->read('Auth.User.id'));
        $this->set(compact('missions'));
        $str = "";
        if($this->Session->read('Auth.User.role_user') == "vendeur") {
            $avant = date("Y-m-d H:i:s", time());
            for($t = 0; $t<10; $t++) {
                $now = $avant;
                $avant1=strtotime($avant)-3600;
                $avant=date("Y-m-d H:i:s",$avant1);
                $missions = $this->Mission->graphe($now, $avant, $this->Session->read('Auth.User.id'));
                $T[$now] = $missions[0][0]["nb"];

            }

            if(!empty($T)) {
                $liste =  array_reverse($T);
                $this->set(compact('liste'));
            }
        }

        if($this->Session->read('Auth.User.role_user') == "admin") {
            $enAttente = $this->User->Paiement->find(('all'), array(
                    'conditions' => array('User.role_user =' => 'vendeur', 'Paiement.admin_id =' => 0, 'Paiement.avatar !=' => '')));
            $this->set(compact('enAttente'));

            $this->loadModel("Usergift");
            $gifts = $this->Usergift->enCours();
            $this->set(compact('gifts'));

            $users = $this->User->newUsers();
            $this->set(compact('users'));

            $newMissions = $this->Mission->newMissions();
            $this->set(compact('newMissions'));
        }

        if($this->Session->read('Auth.User.role_user') == "mobile")
        {
            $visits = $this->User->lastVisits($this->Session->read('Auth.User.id'));
            $this->set(compact('visits'));

            // nb points today
            $points = $this->Session->read('Auth.User.point');
            $avant = date("Y-m-d H:i:s", time());
            $T[date("Y-m-d", time())] = $points;

            for($t = 0; $t<30; $t++) {
                $now = $avant;
                $avant1=strtotime($avant)-86400;
                $avant=date("Y-m-d H:i:s",$avant1);
                $day=date("Y-m-d",$avant1);

                //points - points gagnés + points des cadeaux gagnés
                $points1 = $this->User->pointsGagnes($this->Session->read('Auth.User.id'), $now, $avant);
                $points_moins = $points1[0][0]["nb"];
                $points2 = $this->User->pointsCadeauxGagnes($this->Session->read('Auth.User.id'), $now, $avant);
                $points_plus = $points2[0][0]["nb"];

                $points = $points - $points_moins + $points_plus;
                $T[$day] = $points;
            }
            //print_r($T);
            if(!empty($T)) {
                $liste =  array_reverse($T);
                $this->set(compact('liste'));
            }

        }
    }

    public function view($id)
    {
        $user = $this->User->find('first', array('conditions' => array('id =' => $id)));
        $visits = $this->User->lastVisits($id,1000);
        $this->loadModel("Usergift");
        $gifts = $this->Usergift->miens2($id);
        $this->set(compact('gifts','visits','user'));

            // nb points today
            $points =$user['User']['point'];
            $avant = date("Y-m-d H:i:s", time());
            $T[date("Y-m-d", time())] = $points;

            for($t = 0; $t<30; $t++) {
                $now = $avant;
                $avant1=strtotime($avant)-86400;
                $avant=date("Y-m-d H:i:s",$avant1);
                $day=date("Y-m-d",$avant1);

                //points - points gagnés + points des cadeaux gagnés
                $points1 = $this->User->pointsGagnes($id, $now, $avant);
                $points_moins = $points1[0][0]["nb"];
                $points2 = $this->User->pointsCadeauxGagnes($id, $now, $avant);
                $points_plus = $points2[0][0]["nb"];

                $points = $points - $points_moins + $points_plus;
                $T[$day] = $points;
            }
            //print_r($T);
            if(!empty($T)) {
                $liste =  array_reverse($T);
                $this->set(compact('liste'));
            }
    }
    

    public function add()
    {
        if ($this->request->is('post')) {
            if($this->request->data['User']['password'] != $this->request->data['User']['re_password'] || $this->request->data['User']['password'] == "") {
                $this->Session->setFlash('Mot de passe invalide');
                return;
            }
            //generer code aleatoire
            $characts    = 'abcdefghijklmnopqrstuvwxyz';
            $characts   .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $characts   .= '1234567890';
            $code_aleatoire      = '';
            for($i=0;$i < 20;$i++) {
                $code_aleatoire .= substr($characts,rand()%(strlen($characts)),1);
            }
            $this->request->data['User']['code_password']= $code_aleatoire;
            $this->User->create();
            $this->request->data['User']['role_user']='vendeur';
            $this->request->data['User']['point']=0;
            $this->request->data['User']['active']=0;

            if ($this->User->save($this->request->data)) {
                try {
                    $email = $this->request->data['User']['email'];
                    ini_set("SMTP", "smtp.menara.ma");
                    ini_set("smtp_port", "25");//tester avec 465
                    App::uses('CakeEmail', 'Network/Email');
                    $Email = new CakeEmail();
                    $Email->config('email');
                    $Email->template('default', 'default')
                            ->viewVars(array('lien' => FULL_BASE_URL.'/nada/users/valider/'.$this->User->id.'/'.$code_aleatoire))
                            ->emailFormat('html')
                            ->to($email)
                            ->from('no-replay@proveille.com')
                            ->subject('Validation d/\'inscription')
                            ->send();
                }
                catch(Exception $e) {
                    $this->Session->setFlash(__($e->getMessage()));
                    return;
                }
                $this->Session->setFlash(__('L\'user a été sauvegardé, Vous avez reçu un email de validation de votre compte'));
                return $this->redirect(array('action' => 'index'));
            }
            else {
                $this->Session->setFlash(__('L\'user n\'a pas été sauvegardé. Merci de réessayer.'));
            }
        }
    }


    public function forgotten() {
        if ($this->request->is('post')) {

            //generer code aleatoire
            $characts    = 'abcdefghijklmnopqrstuvwxyz';
            $characts   .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $characts   .= '1234567890';
            $code_aleatoire      = '';
            for($i=0;$i < 20;$i++) {
                $code_aleatoire .= substr($characts,rand()%(strlen($characts)),1);
            }

            $email = $this->request->data['User']['email'];
            $utilisateur = $this->User->find('first', array('conditions' => array('email =' => $email)));

            if($utilisateur == null) return;

            $this->request->data['User']['id'] = $utilisateur['User']['id'];
            $this->request->data['User']['code_password'] = $code_aleatoire;

            try {
                $this->User->save($this->request->data['User'], array('fieldList' => array("code_password")));
                ini_set("SMTP", "smtp.menara.ma");
                ini_set("smtp_port", "25");//tester avec 465
                App::uses('CakeEmail', 'Network/Email');
                $Email = new CakeEmail();
                $Email->config('email');
                $Email->template('reinit', 'default')
                        ->viewVars(array('lien' => FULL_BASE_URL.'/nada/users/reinitialiser/'.$utilisateur['User']['id'].'/'.$code_aleatoire))
                        ->emailFormat('html')
                        ->to($email)
                        ->from('no-replay@icoz.com')
                        ->subject('Réinitialisation du mot de passe proveille')
                        ->send();
            }catch(Exception $e) {
                $this->Session->setFlash(__($e->getMessage()));
                return;
            }

            $this->Session->setFlash('email envoyé !');
            //}

        }
    }


    public function reinitialiser($id, $code) {
        if ($this->request->is('post')) {
            //echo $this->Session->read('user_id');
            //debug($this->request->data);
            if($this->request->data['User']['password'] != "" && $this->request->data['User']['password'] == $this->request->data['User']['re_password']) {
                $this->request->data['User']['id'] =  $this->Session->read('id');
                $this->request->data['User']['code_password'] = "";
                $this->User->save($this->request->data['User'], array('fieldList' => array("code_password","password")));
                return $this->redirect(
                        array('controller' => 'users', 'action' => 'login')
                );
            }else {
                $this->Session->setFlash('Erreur, Veuillez réessayez !');
                return;
            }
        }

        if(isset($id) && isset($code)) {
            $result = $this->User->find(('first'), array(
                    'conditions' => array('id =' => $id, 'code_password' => $code), 'recursive' => -1));
            //debug($result);
            if($result == null ) {
                return $this->redirect(
                        array('controller' => 'users', 'action' => 'login')
                );
            }else {
                $this->Session->write('user_id',$result['User']['id']);
            }
        }else {
            return $this->redirect(
                    array('controller' => 'users', 'action' => 'login')
            );
        }
    }


    public function edit() {
        $this->request->data["User"]["id"]=$this->Session->read('Auth.User.id');
        if ($this->request->is('post') || $this->request->is('put')) 
        {
            $this->User->recursive = -1;
            $conditions = array(
                'User.id' => $this->Session->read('Auth.User.id'),
                'User.password' => AuthComponent::password($this->request->data['User']['password']),
                'User.editer'=>"0"
            );
            if($this->User->hasAny($conditions))
            {
                $this->request->data["User"]["id_mobile"]=$this->Session->read('Auth.User.id_mobile');
                $this->request->data["User"]["point"]=$this->Session->read('Auth.User.point');
                $this->request->data["User"]["created"]=$this->Session->read('Auth.User.created');
                $this->request->data["User"]["role_user"]=$this->Session->read('Auth.User.role_user');
                $this->request->data["User"]["active"]=$this->Session->read('Auth.User.active');
                $this->request->data["User"]["editer"]='editer';
                if ($this->User->save($this->request->data))
                {
                    $this->Session->write('Auth.User.nom_complet', $this->request->data["User"]["nom_complet"]);
                    $this->Session->write('Auth.User.adresse', $this->request->data["User"]["adresse"]);
                    $this->Session->write('Auth.User.tel', $this->request->data["User"]["tel"]);
                    $this->Session->write('Auth.User.email', $this->request->data["User"]["email"]);
                    $this->Session->setFlash(__('L\'user a été modifié'));
                    return $this->redirect(array('action' => 'index'));
                }
                else {
                    $this->Session->setFlash(__('L\'user n\'a pas été modifié. Merci de réessayer.'));
                }
            }
            else
            {
                $this->Session->setFlash(__('Desolé vous ne pouvez pas modifier votre compte'));
                return $this->redirect(array('action' => 'index'));
            }
        }
    }

    public function login() {
        if ($this->request->is('post')) 
        {
            if ($this->Auth->login()) {
                return $this->redirect($this->Auth->redirect());

            } else {
                $this->Session->setFlash(__("Nom d'user ou mot de passe invalide, réessayer"));
            }
        }
    }

    public function valider($id, $code) {
        if(isset($id) && isset($code)) {
            $result = $this->User->find(('first'), array(
                    'conditions' => array('id =' => $id, 'code_password' => $code), 'recursive' => -1));
            //debug($result); die();
            if($result != null ) {
                $this->request->data['User']['id'] = $result['User']['id'];
                $this->request->data['User']['active'] = 1;
                $this->request->data['User']['code_password'] = "";
                if($this->User->save($this->request->data['User'], array('fieldList' => array("active", "code_password"))))
                    $this->Session->setFlash('Félicitation, Vous pivez désormais vous connecter !');
                else $this->Session->setFlash('Erreur, Veuillez réessayer !');
            }
            return $this->redirect(
                    array('controller' => 'users', 'action' => 'login')
            );
        }else {
            return $this->redirect(
                    array('controller' => 'users', 'action' => 'login')
            );
        }
    }

    public function logout() {
        return $this->redirect($this->Auth->logout());
    }

    public function liste() {
        $users = $this->User->find('all');
        $this->set('users', $users);
    }

    public function delete($id) {
        if($this->User->delete($id, true))
            $this->Session->setFlash(__('L\'utilisateur a été supprimé'));
        else
            $this->Session->setFlash(__('L\'utilisateur n\'a pas été supprimé'));
        return $this->redirect($this->Auth->redirect());
    }

    public function modifier($idUser) {
        $user = $this->User->find("first", array("conditions" => array("id" => $idUser), "recursive" => -1));
        $this->set('user', $user);
        if ($this->request->is('post')) {
            if($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('L\'utilisateur a été modifié'));
            }else {
                $this->Session->setFlash(__('L\'utilisateur n\'a pas été modifié'));
            }
            return $this->redirect(array('controller' => 'users', 'action' => 'liste'));
        }
    }


    public function modifpassword()
    {
        if ($this->request->is('post'))
        {
            $this->User->id=$this->Auth->user('id');
            $this->Session->setFlash(__('Mot de passe éroné'));

            if($this->request->data['User']['ppassword'] == $this->request->data['User']['re_password'])
            {
                if(strlen($this->request->data['User']['ppassword'])<5)
                {
                    $this->Session->setFlash(__('Le mot de passe doit avoir une longueur comprise entre 5 et 15 caractères.'));
                    return $this->redirect(array('action' => 'modifpassword'));
                }
                $conditions = array(
                    'User.id' => $this->Session->read('Auth.User.id'),
                    'User.password' => AuthComponent::password($this->request->data['User']['password'])
                );
                if($this->User->hasAny($conditions))
                {
                    $this->User->saveField('password',$this->request->data['User']['ppassword']);
                    $this->Session->setFlash(__('Mot de passe modifier.'));
                    return $this->redirect(array('action' => 'index'));
                }
                else
                {
                    $this->Session->setFlash(__('Mot de passe éroné'));
                }
            }
            return $this->redirect(array('action' => 'modifpassword'));
        }
    }


    public function accueil() 
    {
        $this->layout = 'accuil';
    }

    public function vendeur() {
    }

    public function membre() {
    }

    public function contact() {
    }

    public function apropos()
    {
        $this->layout = 'accuil';
    }


    function addfrommobile()
    {
        if ($this->request->is('post'))
        {
            $characts    = 'abcdefghijklmnopqrstuvwxyz';
            $characts   .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $characts   .= '1234567890';
            $code_aleatoire      = '';
            for($i=0;$i < 20;$i++)
            {
                $code_aleatoire .= substr($characts,rand()%(strlen($characts)),1);
            }
            $this->request->data['User']['code_password']= $code_aleatoire;
            $this->request->data['User']['role_user']='mobile';
            $id=$_POST["id_user"];
            $this->User->id=$id;
            $user=$this->User->findById($id);
            
                $this->request->data['User']['point']=1+$user['User']['point'];
                $this->request->data['User']['active']=0;
                extract($_POST);
                $mobile_id=$_POST["id_mobile"];

                $nomcomplet=$_POST["nom_complet"];
                $this->request->data['User']['nom_complet']=$nomcomplet;
                $age=$_POST["age"];
                $this->request->data['User']['age']=$age;
                $ville=$_POST["ville"];
                $this->request->data['User']['ville']=$ville;
                $email=$_POST["email"];
                $this->request->data['User']['email']=$email;
                $password=$_POST["password"];
                $this->request->data['User']['password']=$password;

                if ($this->User->save($this->request->data))
                {
                    try {
                        $email = $this->request->data['User']['email'];

                        App::uses('CakeEmail', 'Network/Email');
                        $Email = new CakeEmail();
                        $Email->config('email');
                        $Email->template('default', 'default')
                                ->viewVars(array('lien' => FULL_BASE_URL.'/nada/users/valider/'.$this->User->id.'/'.$code_aleatoire))
                                ->emailFormat('html')
                                ->to('godsneek@hotmail.com')
                                ->from('no-replay@myblan.com')
                                ->subject('Validation d/\'inscription')
                                ->send();
                    }
                    catch(Exception $e) {
                        $this->Session->setFlash(__($e->getMessage()));
                        return;
                    }
                    $this->Session->setFlash(__('L\'user a été sauvegardé, Vous avez reçu un email de validation de votre compte'));
                    return $this->redirect(array('action' => 'index'));
                }
                else {
                    $this->Session->setFlash(__('L\'user n\'a pas été sauvegardé. Merci de réessayer.'));
                }
            }
    }

}
?>
