<?php
class MagasinsController extends AppController {

    public function isAuthorized($user) 
    {
        if($user['role_user'] == "mobile") {
            if ($this->action === 'view') {
                return true;
            }
            return false;
        }
        if($user['role_user'] == "admin") {
            if ($this->action === 'liste' || $this->action === 'view' || $this->action === 'delete' || $this->action === 'edit') {
                return true;
            }else return false;
        }else {
            if ($user['role_user'] == "vendeur" && ($this->action === 'view' || $this->action === 'add'  || $this->action === 'miens' || $this->action === 'delete' || $this->action === 'edit')) {
                return true;
            }else
                return false;
        }
        return parent::isAuthorized($user);
    }


    public function index() {
    }

    public function add() {
        if ($this->request->is('post'))
        {
            $ext = strtolower(pathinfo($this->request->data['Magasin']['url_image']['name'], PATHINFO_EXTENSION ));
            $file=@$this->request->data['Magasin']['url_image']['tmp_name'];
            if(!empty($file) && in_array($ext, array('jpeg', 'jpg', 'png')))
            {
                $data = $this->Magasin->maxid();
                $nomFile = $data[0][0]['max']+1;
                move_uploaded_file($this->request->data['Magasin']['url_image']['tmp_name'], IMAGES.'imgProjet'.DS.$nomFile.'.'.$ext);
                $this->request->data['Magasin']['url_image'] = $nomFile.'.'.$ext;
            }
            else
                $this->request->data['Magasin']['url_image']='';
            $this->request->data['Magasin']['user_id']=AuthComponent::user('id');
            $this->Magasin->create();
            if ($this->Magasin->save($this->request->data)) {
                $this->Session->setFlash(__('Le magasin a été sauvegardé !'));
                return $this->redirect(array('action' => 'miens'));
            }
            else {
                $this->Session->setFlash(__('Le magasin n\'a pas été sauvegardé. Merci de réessayer.'));
            }
        }
    }

    public function edit($id)
    {
        $magasin = $this->Magasin->find("first", array("conditions" => array("id_magasin" => $id), "recursive" => -1));
        $this->set('magasin', $magasin);
        if ($this->request->is('post'))
        {
            $ext = strtolower(pathinfo($this->request->data['Magasin']['url_image']['name'], PATHINFO_EXTENSION ));
            if(!empty($this->request->data['Magasin']['url_image']['tmp_name'])
                    && in_array($ext, array('jpeg', 'jpg', 'png')))
             {
                $nomFile = $magasin['Magasin']['url_image'];
                move_uploaded_file($this->request->data['Magasin']['url_image']['tmp_name'], IMAGES.'imgProjet'.DS.$nomFile);
                $this->request->data['Magasin']['url_image'] = $nomFile;
                if ($this->Magasin->save($this->request->data)) {
                    $this->Session->setFlash(__('Magasin a été modifié'));
                    return $this->redirect(array('controller' => 'magasins', 'action' => 'miens'));
                }else {
                    $this->Session->setFlash(__('Magasin n\'a pas été modifié'));
                }
            }

        }
    }

    public function liste() {
        $magasins = $this->Magasin->liste();
        $this->set('magasins', $magasins);
    }

    public function miens() {
        $magasins = $this->Magasin->miens($this->Session->read('Auth.User.id'));
        $this->set('magasins', $magasins); 
    }

    public function delete($id) {
        if($this->Magasin->delete($id, true))
            $this->Session->setFlash(__('Magasin a été supprimé'));
        else
            $this->Session->setFlash(__('Magasin n\'a pas été supprimé'));
        if($this->Session->read('Auth.User.role_user') == "vendeur")
            return $this->redirect(array('controller' => 'magasins', 'action' => 'miens'));
        else return $this->redirect(array('controller' => 'magasins', 'action' => 'liste'));
    }

    public function view($idMagasin) 
    {
        $magasin = $this->Magasin->findByIdMagasin($idMagasin);
        $this->set('magasin', $magasin);
    }

}
