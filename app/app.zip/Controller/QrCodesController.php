<?php

class QrCodesController extends AppController{
     public $helpers = array('QrCode');

public function isAuthorized($user) {
    if($user['role_user'] != "mobile"){
       return false;
    }
    return parent::isAuthorized($user);
}

     public function Viewqrcode(){
         $texte=$this->request->data['a'];
         $this->set('text',$texte); 
     }
//     public function test(){
//
//     }

     public function mespoints(){
        $points = $this->QrCode->mesPoints($this->Session->read('Auth.User.id'));
        $this->set('points',$points);
     }
     
}
?>
