<?php
class ContenusController extends AppController{

public function isAuthorized($user) {
   if($user['role_user'] == "vendeur" && ($this->action === 'liste' || $this->action === 'add' || $this->action === 'delete')){
            return true;
       }
    return false;
}


public function liste(){
    $this->loadModel('Contenu');
   $contenus = $this->Contenu->find('all', array("conditions" => array("user_id =" => $this->Session->read('Auth.User.id_user')), "recursive" => -1));
   $this->set('contenus', $contenus);
}


public function add(){
     if ($this->request->is('post')) {
           $this->loadModel('Contenu');
           $ext = strtolower(pathinfo($this->request->data['Contenu']['image']['name'], PATHINFO_EXTENSION ));
           if(!empty($this->request->data['Contenu']['image']['tmp_name']) && in_array($ext, array('jpeg', 'jpg', 'png')))
           {
                $data = $this->Contenu->maxid();
                $nomFile = $data[0][0]['max']+1;
                move_uploaded_file($this->request->data['Contenu']['image']['tmp_name'], IMAGES.'imgContenu'.DS.$nomFile.'.'.$ext);
                $this->request->data['Contenu']['logo'] = $nomFile.'.'.$ext;
           }
           $this->request->data['Contenu']['user_id'] = $this->Session->read('Auth.User.user_id');
           $this->Contenu->create();
           if ($this->Contenu->save($this->request->data))
           {
                $this->Session->setFlash(__('Le Contenu a été sauvegardé !'));
                $this->redirect(array('action' => 'liste'));
            }else {
                $this->Session->setFlash(__('Le Contenu n\'a pas été sauvegardé. Merci de réessayer.'));
            }
        }
}

public function delete($id){
    $this->loadModel('Contenu');
    if($this->Contenu->delete($id, true))
        $this->Session->setFlash(__('Contenu a été supprimé'));
    else
        $this->Session->setFlash(__('Contenu n\'a pas été supprimé'));
        return $this->redirect(array('controller' => 'contenus', 'action' => 'liste'));
}

}
